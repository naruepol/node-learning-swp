export interface LoginDTO {
  email: string;
  pwd: string;
}

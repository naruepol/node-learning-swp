export interface UserDTO {
  code: string;
  name: string;
  email: string;
  pwd: string;
}

export class NewContactResp {
  success: boolean;
}

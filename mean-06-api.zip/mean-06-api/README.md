# Software Engineering
``` javascript
const fs = require("fs");
```
# **MEAN**

1. MongoDB
1. Express
1. Angular
1. Node

# ** MERN **
* MongoDB
* Express
* React
* Node
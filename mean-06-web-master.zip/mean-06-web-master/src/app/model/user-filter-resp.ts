export interface UserFilterResp {
  code: string;
  name: string;
  email: string;
  pwd: string;
  active: string;
  role: string;
}

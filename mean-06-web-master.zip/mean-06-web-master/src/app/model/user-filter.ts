export interface UserFilter {
  code: string;
  name: string;
  email: string;
  role: string;
  active: string;
}

export interface User {
  code: string;
  name: string;
  pwd: string;
  email: string;
}
